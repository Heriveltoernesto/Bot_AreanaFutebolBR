const { Client, GatewayIntentBits } = require('discord.js');
const axios = require('axios');
require('dotenv').config();

const client = new Client({ 
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildMembers
  ] 
});

const API_KEY = '49e8e7f98754a969ec922a842d7ad086';

client.once('ready', () => {
  console.log(`✅ ArenaFutebolBR está online!`);
  client.guilds.cache.forEach(guild => {
    const channel = guild.channels.cache.find(ch => ch.type === 0 && ch.permissionsFor(guild.members.me).has('SendMessages'));
    if (channel) {
      mostrarInstrucoes(channel);
      verificarJogosProximos(channel);
    }
  });
  
  // Verificar jogos a cada 6 horas
  setInterval(() => {
    client.guilds.cache.forEach(guild => {
      const channel = guild.channels.cache.find(ch => ch.type === 0 && ch.permissionsFor(guild.members.me).has('SendMessages'));
      if (channel) verificarJogosProximos(channel);
    });
  }, 6 * 60 * 60 * 1000);
});

async function verificarJogosProximos(channel) {
  try {
    const today = new Date().toISOString().split('T')[0];
    const response = await axios.get('https://v3.football.api-sports.io/fixtures', {
      headers: { 'x-apisports-key': API_KEY },
      params: { date: today, season: 2024 }
    });

    const standings = await axios.get('https://v3.football.api-sports.io/standings', {
      headers: { 'x-apisports-key': API_KEY },
      params: { season: 2024 }
    });

    const jogos = response.data.response;
    if (jogos.length === 0) return;

    let msg = '🚨 **ALERTA DE JOGOS HOJE**\n\n';
    
    for (const jogo of jogos) {
      const league = standings.data.response.find(l => l.league.id === jogo.league.id);
      const homeTeam = league?.standings[0]?.find(team => team.team.id === jogo.teams.home.id);
      const awayTeam = league?.standings[0]?.find(team => team.team.id === jogo.teams.away.id);
      
      msg += `🏆 **${jogo.league.name}**\n`;
      msg += `⚽ ${jogo.teams.home.name} x ${jogo.teams.away.name}\n`;
      msg += `⏰ Horário: ${new Date(jogo.fixture.date).toLocaleTimeString('pt-BR')}\n`;
      
      if (homeTeam && awayTeam) {
        msg += `📊 Estatísticas:\n`;
        msg += `   ${jogo.teams.home.name}: ${homeTeam.rank}º lugar (${homeTeam.points} pts)\n`;
        msg += `   ${jogo.teams.away.name}: ${awayTeam.rank}º lugar (${awayTeam.points} pts)\n`;
      }
      
      msg += `🏟️ Estádio: ${jogo.fixture.venue.name || 'Não informado'}\n\n`;
    }

    channel.send({
      embeds: [{
        color: 0xFF4500,
        title: '📢 Notificação de Jogos',
        description: msg,
        timestamp: new Date(),
        footer: {
          text: 'ArenaFutebolBR - Acompanhe todos os jogos!'
        }
      }]
    });

  } catch (error) {
    console.error('Erro ao verificar jogos próximos:', error);
  }
}

function mostrarInstrucoes(channel) {
  const embed = {
    color: 0x0099ff,
    title: '🎮 Bem-vindo ao ArenaFutebolBR!',
    description: 'Bot de resultados esportivos em tempo real',
    fields: [
      {
        name: '⚽ Comandos de Futebol',
        value: '`/jogos` - Ver jogos de hoje\n`/br a/b/c/d` - Ver jogos do Brasileirão\n`/internacional` - Ver jogos internacionais\n`/todos` - Ver todos os jogos',
      },
      {
        name: '🏆 Outros Esportes',
        value: '`/basquete` - Ver jogos de basquete\n`/volei` - Ver jogos de vôlei\n`/beisebol` - Ver jogos de beisebol',
      },
      {
        name: '🏎️ Automobilismo',
        value: '`/f1` - Ver corridas de F1\n`/formula-truck` - Ver corridas de Formula Truck',
      },
      {
        name: '⚙️ Comandos de Busca',
        value: '`/live add <nome>` - Buscar competições/times',
      },
      {
        name: '👑 Comandos Admin',
        value: '`/admin update` - Ver status do bot\n`/admin league add <id>` - Adicionar nova liga',
      }
    ],
    timestamp: new Date(),
    footer: {
      text: 'Use /help para ver esta mensagem novamente'
    }
  };
  
  channel.send({ embeds: [embed] });
}

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  const content = message.content.toLowerCase();

  if (content.startsWith('/jogos')) {
    await buscarJogosHoje(message);
  } else if (content.startsWith('/br')) {
    const serie = content.split(' ')[1]?.toLowerCase();
    await buscarBrasileirao(message, serie);
  } else if (content.startsWith('/internacional')) {
    await buscarInternacionais(message);
  } else if (content.startsWith('/basquete')) {
    await buscarBasquete(message);
  } else if (content.startsWith('/volei')) {
    await buscarVolei(message);
  } else if (content.startsWith('/beisebol')) {
    await buscarBeisebol(message);
  } else if (content.startsWith('/f1')) {
    await buscarF1(message);
  } else if (content.startsWith('/formula-truck')) {
    await buscarFormulaTruck(message);
  } else if (content.startsWith('/todos')) {
    await buscarTodosJogos(message);
  } else if (content.startsWith('/live')) {
    const query = content.split('/live add ')[1];
    if (query) {
      await buscarCompeticoes(message, query);
    } else {
      message.reply('❌ Use: `/live add <nome-da-competicao-ou-time>`');
    }
  } else if (content.startsWith('/admin league add')) {
    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply('❌ Apenas administradores podem usar este comando.');
    }
    const leagueId = content.split('/admin league add ')[1];
    if (leagueId) {
      await adicionarLiga(message, leagueId);
    } else {
      message.reply('❌ Use: `/admin league add <league-id>`');
    }
  } else if (content === '/admin update') {
    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply('❌ Apenas administradores podem usar este comando.');
    }
    await atualizarBot(message);
  } else if (content === '/help') {
    mostrarInstrucoes(message.channel);
  }
});

async function atualizarBot(message) {
  try {
    const updateMsg = '🤖 **Bot Update Status:**\n' +
      '✅ Versão: 1.0.0\n' +
      '📅 Última atualização: ' + new Date().toLocaleDateString() + '\n' +
      '🔄 Status: Online\n' +
      '📊 API Status: Conectado\n' +
      '🏆 Ligas ativas: Brasileirão A, B, C, D\n' +
      '⚙️ Comandos ativos: /jogos, /br, /internacional, /todos, /live, /admin';
    
    message.reply(updateMsg);
  } catch (error) {
    console.error(error);
    message.reply('⚠️ Erro ao verificar atualizações.');
  }
}

async function adicionarLiga(message, leagueId) {
  try {
    const response = await axios.get(`https://v3.football.api-sports.io/leagues`, {
      headers: { 'x-apisports-key': API_KEY },
      params: { id: leagueId }
    });

    const liga = response.data.response[0];
    if (!liga) {
      return message.reply('❌ Liga não encontrada.');
    }

    message.reply(`✅ Liga adicionada com sucesso!\n🏆 **${liga.league.name}**\n📍 País: ${liga.country.name}\n📅 Temporada: ${liga.seasons[0].year}`);
  } catch (error) {
    console.error(error);
    message.reply('⚠️ Erro ao adicionar liga.');
  }
}

async function buscarCompeticoes(message, query) {
  try {
    const response = await axios.get('https://v3.football.api-sports.io/leagues', {
      headers: { 'x-apisports-key': API_KEY },
      params: { search: query }
    });

    const ligas = response.data.response;
    if (ligas.length === 0) return message.reply('🔍 Nenhuma competição encontrada.');

    let msg = '🌍 **Competições Encontradas:**\n\n';
    ligas.forEach(liga => {
      msg += `🏆 **${liga.league.name}**\n`;
      msg += `📍 País: ${liga.country.name}\n`;
      msg += `🔢 ID: ${liga.league.id}\n`;
      msg += `📅 Temporada atual: ${liga.seasons[0].year}\n\n`;
    });

    message.reply(msg);
  } catch (error) {
    console.error(error);
    message.reply('⚠️ Erro ao buscar competições.');
  }
}

async function buscarTodosJogos(message) {
  try {
    const today = new Date().toISOString().split('T')[0];
    const response = await axios.get('https://v3.football.api-sports.io/fixtures', {
      headers: { 'x-apisports-key': API_KEY },
      params: { date: today, season: 2024 }
    });

    const jogos = response.data.response;
    if (jogos.length === 0) return message.reply('⚽ Nenhum jogo encontrado hoje.');

    let msg = '📅 **Todos os Jogos de Hoje:**\n\n';
    
    // Agrupar jogos por liga
    const jogosPorLiga = {};
    jogos.forEach(jogo => {
      const ligaNome = jogo.league.name;
      if (!jogosPorLiga[ligaNome]) {
        jogosPorLiga[ligaNome] = [];
      }
      jogosPorLiga[ligaNome].push(jogo);
    });

    // Criar mensagem organizada por liga
    for (const [liga, jogosLiga] of Object.entries(jogosPorLiga)) {
      msg += `\n🏆 **${liga}**\n`;
      jogosLiga.forEach(jogo => {
        const status = jogo.fixture.status.short === 'NS' ? '⏰ Em breve' : 
                      jogo.fixture.status.elapsed ? `⚽ ${jogo.fixture.status.elapsed}'` : 
                      '🔄 ' + jogo.fixture.status.short;
        
        const scoreColor = jogo.fixture.status.short === 'NS' ? '⚪' :
                          jogo.fixture.status.short === 'FT' ? '🟢' :
                          jogo.fixture.status.elapsed ? '🟡' : '⚪';
                      
        msg += `${scoreColor} ${jogo.teams.home.name} **${jogo.goals.home ?? 0} x ${jogo.goals.away ?? 0}** ${jogo.teams.away.name} (${status})\n`;
      });
    }

    // Dividir mensagem se for muito grande
    if (msg.length > 2000) {
      const chunks = msg.match(/.{1,1900}/g);
      for (const chunk of chunks) {
        await message.reply(chunk);
      }
    } else {
      await message.reply(msg);
    }

  } catch (error) {
    console.error(error);
    message.reply('⚠️ Erro ao buscar os jogos.');
  }
}

async function buscarJogosHoje(message) {
  try {
    const today = new Date().toISOString().split('T')[0];
    const response = await axios.get('https://v3.football.api-sports.io/fixtures', {
      headers: { 'x-apisports-key': API_KEY },
      params: { date: today, season: 2024 }
    });

    const jogos = response.data.response;
    if (jogos.length === 0) return message.reply('⚽ Nenhum jogo encontrado hoje.');

    let msg = '🏆 **Jogos de Hoje:**\n\n';
    jogos.forEach(jogo => {
      msg += `📍 ${jogo.teams.home.name} ${jogo.goals.home ?? 0} x ${jogo.goals.away ?? 0} ${jogo.teams.away.name} (${jogo.fixture.status.elapsed || 'N/A'} min)\n`;
    });

    message.reply(msg);
  } catch (error) {
    console.error(error);
    message.reply('⚠️ Erro ao buscar os jogos.');
  }
}

async function buscarBrasileirao(message, serie) {
  const seriesMap = { a: 71, b: 72, c: 73, d: 74 };
  const leagueId = seriesMap[serie];

  if (!leagueId) return message.reply('❌ Série inválida. Use: `!br a`, `!br b`, `!br c` ou `!br d`');

  try {
    const today = new Date().toISOString().split('T')[0];
    const response = await axios.get('https://v3.football.api-sports.io/fixtures', {
      headers: { 'x-apisports-key': API_KEY },
      params: { league: leagueId, season: 2024, date: today }
    });

    const jogos = response.data.response;
    if (jogos.length === 0) return message.reply(`🏆 Série ${serie.toUpperCase()} - Nenhum jogo hoje.`);

    let msg = `🏆 Brasileirão Série ${serie.toUpperCase()} - Jogos de hoje:\n\n`;
    jogos.forEach(jogo => {
      msg += `📍 ${jogo.teams.home.name} ${jogo.goals.home ?? 0} x ${jogo.goals.away ?? 0} ${jogo.teams.away.name} (${jogo.fixture.status.elapsed || 'N/A'} min)\n`;
    });

    message.reply(msg);
  } catch (error) {
    console.error(error);
    message.reply('⚠️ Erro ao buscar os jogos.');
  }
}

async function buscarInternacionais(message) {
  try {
    const today = new Date().toISOString().split('T')[0];
    const response = await axios.get('https://v3.football.api-sports.io/fixtures', {
      headers: { 'x-apisports-key': API_KEY },
      params: { date: today, season: 2024 }
    });

    const jogos = response.data.response.filter(jogo => jogo.league.type === 'Cup' || jogo.league.type === 'League');
    if (jogos.length === 0) return message.reply('🌍 Nenhum jogo internacional encontrado.');

    let msg = '🌍 **Campeonatos Internacionais - Jogos de Hoje:**\n\n';
    jogos.forEach(jogo => {
      msg += `📍 ${jogo.teams.home.name} ${jogo.goals.home ?? 0} x ${jogo.goals.away ?? 0} ${jogo.teams.away.name} (${jogo.fixture.status.elapsed || 'N/A'} min)\n`;
    });

    message.reply(msg);
  } catch (error) {
    console.error(error);
    message.reply('⚠️ Erro ao buscar os jogos internacionais.');
  }
}

async function buscarBasquete(message) {
  message.reply('🏀 Ainda não implementado.');
}

async function buscarVolei(message) {
  message.reply('🏐 Ainda não implementado.');
}

async function buscarBeisebol(message) {
  message.reply('⚾ Ainda não implementado.');
}

async function buscarF1(message) {
  message.reply('🏎️ Ainda não implementado.');
}

async function buscarFormulaTruck(message) {
  message.reply('🚛 Ainda não implementado.');
}

async function listarCanaisEsporte(message) {
  const canais = [
    {
      nome: "ESPN Brasil",
      comando: "/espn",
      url: "https://www.youtube.com/@ESPNBrasil",
      descricao: "Canal oficial da ESPN Brasil",
      icone: "🏆"
    },
    {
      nome: "TNT Sports Brasil",
      comando: "/tnt", 
      url: "https://www.youtube.com/@TNTSportsBR",
      descricao: "Canal da TNT Sports com conteúdo gratuito",
      icone: "⚽"
    },
    {
      nome: "Cartola FC",
      comando: "/cartola",
      url: "https://www.youtube.com/@CartolaFC",
      descricao: "Canal oficial do Cartola FC",
      icone: "🎮"
    },
    {
      nome: "Canal do VSR",
      comando: "/vsr",
      url: "https://www.youtube.com/@CanalDoVSR",
      descricao: "Canal com análises e debates esportivos",
      icone: "📺"
    }
  ];

  const embed = {
    color: 0xFF0000,
    title: '📺 Canais de Esporte no YouTube',
    description: 'Lista de canais gratuitos para acompanhamento esportivo:',
    fields: canais.map(canal => ({
      name: `${canal.icone} ${canal.nome}`,
      value: `${canal.descricao}\nComando: \`${canal.comando}\`\n[Assistir](${canal.url})`
    })),
    footer: {
      text: 'Use os comandos específicos ou /youtube para ver a lista'
    }
  };

  message.channel.send({ embeds: [embed] });
}

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  const content = message.content.toLowerCase();

  const comandosCanais = {
    '/youtube': () => listarCanaisEsporte(message),
    '/espn': () => message.reply('🏆 ESPN Brasil: https://www.youtube.com/@ESPNBrasil'),
    '/tnt': () => message.reply('⚽ TNT Sports: https://www.youtube.com/@TNTSportsBR'),
    '/cartola': () => message.reply('🎮 Cartola FC: https://www.youtube.com/@CartolaFC'),
    '/vsr': () => message.reply('📺 Canal do VSR: https://www.youtube.com/@CanalDoVSR')
  };

  if (comandosCanais[content]) {
    await comandosCanais[content]();
  } else if (content.startsWith('/youtube ')) {
    const canalNome = content.slice(9);
    const canais = {
      'espn': 'https://www.youtube.com/@ESPNBrasil',
      'tnt': 'https://www.youtube.com/@TNTSportsBR',
      'cartola': 'https://www.youtube.com/@CartolaFC',
      'vsr': 'https://www.youtube.com/@CanalDoVSR'
    };
    
    const url = canais[canalNome];
    if (url) {
      message.reply(`📺 Aqui está o link do canal: ${url}`);
    } else {
      message.reply('❌ Canal não encontrado. Use /youtube para ver a lista de canais disponíveis.');
    }
  }

  // Existing commands...
  if (content.startsWith('/jogos')) {
    await buscarJogosHoje(message);
  } else if (content.startsWith('/br')) {
    const serie = content.split(' ')[1]?.toLowerCase();
    await buscarBrasileirao(message, serie);
  } // ... rest of the existing commands
});

client.login(process.env.DISCORD_TOKEN);
